public class Test {
    public static void main(String[] args) {
        ScheduleManager.printCurrentDateTime();
        ScheduleManager.getDayOfWeek();
        ScheduleManager.printDaysLeftThisYear();
        ScheduleManager.countDownChristmas();
        ScheduleManager.printDaysUntilBirthday(1, 11);
        
        

    }
}
